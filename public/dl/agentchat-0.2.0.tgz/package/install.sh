#!/bin/sh
# Installs or updates Agentchat under ~/.agentchat from this unpacked package, then runs `agentchat join` with the invite and flags passed in.
# The one-line invite verifies the package's SHA-256 before this runs; this script pins Node the same way.
set -eu

NODE_VERSION=24.22.0
NODE_SHA256_ARM64=75ddfb875bbd868ebe57536f4442225f54dd10f6d2178dd439de869a5c648dc3
NODE_SHA256_X64=b890d687983ddc811641f6739c3ce99d2912c58f9e44b68aa25944037b425305

die() { printf 'agentchat: %s\n' "$*" >&2; exit 1; }
quote() { printf "'%s'" "$(printf '%s' "$1" | sed "s/'/'\\\\''/g")"; }
at_least() { awk -v a="$1" -v b="$2" 'BEGIN { split(a, x, "."); split(b, y, "."); for (i = 1; i <= 3; i++) { if (x[i] + 0 > y[i] + 0) exit 0; if (x[i] + 0 < y[i] + 0) exit 1 } exit 0 }'; }

[ "$(id -u)" != 0 ] || die "Run this as yourself, not with sudo."
[ "$(uname -s)" = Darwin ] || die "Agentchat runs on macOS: it keeps your keys in the Keychain and the Secure Enclave."
os=$(sw_vers -productVersion)
at_least "$os" 13.5 || die "Agentchat needs macOS 13.5 or newer; this Mac has $os."

here=$(cd "$(dirname "$0")" && pwd -P)
version=$(sed -n 's/^[[:space:]]*"version":[[:space:]]*"\([0-9][0-9]*\.[0-9][0-9]*\.[0-9][0-9]*\)".*/\1/p' "$here/package.json" | head -n 1)
[ -n "$version" ] || die "This folder isn't an Agentchat package: $here"

# Apple Silicon reports hw.optional.arm64=1 even from a Rosetta shell; Intel Macs don't have the key at all.
if [ "$(/usr/sbin/sysctl -n hw.optional.arm64 2>/dev/null || true)" = 1 ]; then arch=arm64 node_sha=$NODE_SHA256_ARM64; else arch=x64 node_sha=$NODE_SHA256_X64; fi

root=$HOME/.agentchat
mkdir -p "$root/node" "$root/app" "$root/bin"
for stale in "$root"/node/.tmp-* "$root"/app/.tmp-* "$root"/bin/.tmp-*; do
  if [ -e "$stale" ]; then rm -rf "$stale"; fi
done

node_dir=$root/node/v$NODE_VERSION-$arch
if [ ! -x "$node_dir/bin/node" ]; then
  printf 'Downloading Node %s for this Mac (about 25 MB)...\n' "$NODE_VERSION"
  tmp=$root/node/.tmp-$$
  mkdir -p "$tmp"
  curl -f#SL "https://nodejs.org/dist/v$NODE_VERSION/node-v$NODE_VERSION-darwin-$arch.tar.xz" -o "$tmp/node.tar.xz"
  echo "$node_sha  $tmp/node.tar.xz" | shasum -a 256 -c -s || die "The Node download didn't match its pinned SHA-256, so nothing was installed. Paste the same line again."
  tar -xJf "$tmp/node.tar.xz" -C "$tmp" "node-v$NODE_VERSION-darwin-$arch/bin/node" "node-v$NODE_VERSION-darwin-$arch/LICENSE"
  rm -rf "$node_dir"
  mv "$tmp/node-v$NODE_VERSION-darwin-$arch" "$node_dir"
  rm -rf "$tmp"
  [ -x "$node_dir/bin/node" ] || die "Node didn't install correctly. Paste the same line again."
fi

# A version's folder is never rewritten: a running agent may still load files or the Touch ID helper from it.
app=$root/app/$version
if [ ! -f "$app/package.json" ]; then
  tmp=$root/app/.tmp-$$
  cp -R "$here" "$tmp"
  rm -rf "$app"
  mv "$tmp" "$app"
fi

shim=$root/bin/agentchat
current=$(sed -n 's|^exec .*/app/\([0-9][0-9]*\.[0-9][0-9]*\.[0-9][0-9]*\)/bin/agentchat\.js.*|\1|p' "$shim" 2>/dev/null || true)
if [ -n "$current" ] && ! at_least "$version" "$current"; then
  printf 'Agentchat %s is already installed, so this older %s package was left unused.\n' "$current" "$version"
else
  tmp=$root/bin/.tmp-$$
  printf '#!/bin/sh\nexec %s %s "$@"\n' "$(quote "$node_dir/bin/node")" "$(quote "$app/bin/agentchat.js")" > "$tmp"
  chmod 755 "$tmp"
  mv -f "$tmp" "$shim"
fi

# Bash stops reading ~/.profile once ~/.bash_profile exists, so the block goes into whichever of the two is already there.
case "${SHELL:-}" in
  */zsh) profile=$HOME/.zprofile ;;
  */bash) if [ -f "$HOME/.bash_profile" ] || [ ! -f "$HOME/.profile" ]; then profile=$HOME/.bash_profile; else profile=$HOME/.profile; fi ;;
  *) profile= ;;
esac
if [ -n "$profile" ] && ! grep -qs '# >>> agentchat >>>' "$profile"; then
  printf '\n# >>> agentchat >>>\nexport PATH="$HOME/.agentchat/bin:$PATH"\n# <<< agentchat <<<\n' >> "$profile"
fi

tarball=$(dirname "$here")/agentchat-$version.tgz
if [ -f "$tarball" ]; then set -- "$@" --package-sha "$(shasum -a 256 "$tarball" | cut -d ' ' -f 1)"; fi

if "$shim" join "$@"; then
  case ":$PATH:" in
    *":$root/bin:"*) ;;
    *) if [ -n "$profile" ]; then printf '\nOpen a new Terminal window to use the agentchat command.\n'; else printf '\nAdd %s to your PATH to use the agentchat command.\n' "$root/bin"; fi ;;
  esac
else
  status=$?
  printf '\nSetup stopped before finishing. Fix what it says above (for example, pick another name with --as), then paste the same line again.\n' >&2
  exit "$status"
fi
